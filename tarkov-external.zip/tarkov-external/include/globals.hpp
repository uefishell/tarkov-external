#ifndef GLOBALS_HPP
#define GLOBALS_HPP

#include "double_buffer_container.hpp"
#include "sdk.hpp"

#include "rpc/mono_rpc.hpp"

#define NOMINMAX
#include <renderer/buffer.hpp>
#include <renderer/renderer.hpp>

#include <atomic>
#include <fstream>
#include <iostream>
#include <shared_mutex>
#include <string_view>
#include <future>
#include <numeric>

// TODO: Delete this after testing mono rpc
inline uint64_t unity_engine_renderer_custom_set_material = 0;

namespace game {
    extern uint64_t _discord;

    extern std::shared_ptr<rpc::mono_rpc> mono_rpc;

    extern std::shared_mutex mutex;

    bool initialize();

    inline std::atomic<bool> market_success;
    inline std::future<bool> market_future;

    extern std::atomic<bool> running;
    extern volatile size_t max_fps;
    extern volatile size_t fps;
    extern volatile size_t sleep_tick;
    extern volatile size_t sleep_second;
    extern volatile size_t tick_rate;

    extern eft::game_world game_world;
    extern eft::tarkov_application tarkov_application;

    extern eft::camera_control::camera_manager camera_manager;
    extern unity_engine::camera main_camera;
    extern glm::mat4x4 view_matrix;
    extern eft::camera_control::optic_camera_manager optic_camera_manager;
    extern unity_engine::camera optic_camera;

    extern eft::level_settings level_settings;
    extern eft::network::network_game<eft::game_player_owner> network_game;
    extern eft::quests::quest_template_manager quest_template_manager;

    extern eft::player main_player;
    extern unity_engine::transform_internal main_player_current_fireport;

    extern std::shared_mutex cached_players_mutex;
    extern std::unordered_map<uint64_t, std::shared_ptr<sdk::cached_player>> cached_players;
    extern std::deque<std::shared_ptr<sdk::cached_player>> new_cached_players;

    struct cached_target {
        std::shared_ptr<sdk::cached_player> player;
        float time_to_target;
        glm::vec3 predicted_position;
    };

    extern cached_target target;

    struct cached_exfiltration {
        std::wstring name;
        glm::vec3 position;
        eft::interactive::e_exfiltration_status status;
        eft::interactive::e_exfiltration_type type;
    };

    extern std::shared_mutex cached_exfiltrations_mutex;
    extern std::vector<std::shared_ptr<cached_exfiltration>> cached_exfiltrations;

    extern int32_t previous_loot_list_size;
    //extern std::unordered_map<uint64_t, std::shared_ptr<eft::interactive::stationary_weapon>> cached_stationary_weapons;

    // TODO: Revamped simple object caching
    enum loot_rarity : int32_t {
        worthless = (1 << 0),
        common = (1 << 1),
        uncommon = (1 << 2),
        rare = (1 << 3),
        epic = (1 << 4),
        legendary = (1 << 5),
        quest = (1 << 6),
        unknown = (1 << 7),
        user_filter = (1 << 8)
    };

    struct container_item {
        std::wstring label;
        int32_t rarity;
        int32_t price;
        std::wstring id;
    };

    struct cached_item {
        glm::vec3 position {};
        std::wstring label;
        std::wstring id;
        std::vector<container_item> items;
        int64_t total_value() {
            return std::accumulate(items.begin(), items.end(), 0, [](auto total, const container_item& item) -> auto {
                return total + item.price;
            });
        }

        cached_item() = default;
        cached_item(glm::vec3 position, std::wstring label, std::wstring id)
            : position(position), label(std::move(label)), id(std::move(id)) {}
    };

    struct cached_loot_item : cached_item {
        int32_t rarity;

        cached_loot_item() = default;
        cached_loot_item(glm::vec3 position, std::wstring label, std::wstring id, int32_t rarity)
            : cached_item(position, std::move(label), std::move(id)), rarity(rarity) {}
    };

    struct cached_container : cached_item {
        cached_container() = default;
        cached_container(glm::vec3 position, std::wstring label, std::wstring id)
            : cached_item(position, std::move(label), std::move(id)) {}
    };

    struct cached_corpse : cached_item {
        cached_corpse() = default;
        cached_corpse(glm::vec3 position, std::wstring label, std::wstring id, bool player)
            : cached_item(position, std::move(label), std::move(id)), player(player) {}

        bool player = false;
    };

    extern double_buffer_container<std::unordered_map<uint64_t, cached_corpse>> cached_corpses;
    extern double_buffer_container<std::unordered_map<uint64_t, cached_container>> cached_containers;
    extern double_buffer_container<std::unordered_map<uint64_t, cached_loot_item>> cached_loot_items;
} // namespace game

namespace visuals {
    extern std::unique_ptr<renderer::d3d11_renderer> dx11;

    extern size_t visual2d_buf_id;
    extern size_t visual3d_buf_id;
    extern size_t visual3d_lines_buf_id;
    extern size_t ui_buf_id;

    extern renderer::buffer* buf2d;
    extern renderer::buffer* buf3d;
    extern renderer::buffer* buf3d_lines;
    extern renderer::buffer* ui_buffer;

    extern float normal_font_size;

    extern renderer::text_font* segoe_ui_font;
} // namespace visuals

#endif