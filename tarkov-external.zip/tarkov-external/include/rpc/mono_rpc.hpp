#ifndef RPC_MONO_RPC_HPP
#define RPC_MONO_RPC_HPP

#include <Windows.h>

#include <mdissect/mdissect.hpp>

#include "base_rpc.hpp"

#include "memory.hpp"

namespace rpc {
    class mono_rpc {
    public:
        mono_rpc() = delete;
        mono_rpc(const mdissect::mono_domain& domain, const std::shared_ptr<base_rpc>& rpc) : domain_(domain), rpc_(rpc) {}

        // Mono
        // Call the mono_thread_attach() function before you execute any other Mono API or before manipulating any managed object
        bool mono_thread_attach() {
            static auto mono_thread_attach = get_mono_export_method("mono_thread_attach");
            if (mono_thread_attach == 0)
                return false;

            const auto response = rpc_->invoke<uint64_t>(mono_thread_attach, domain_.address);

            return response.error == RPC_OK;
        }

        // Using to find methods that I can't find through normal means with mdissect
        mdissect::mono_method mono_class_get_method_from_name(const mdissect::mono_class& klass, const std::string& name, const int32_t param_count = -1) {
            static auto mono_class_get_method_from_name = get_mono_export_method("mono_class_get_method_from_name");
            if (mono_class_get_method_from_name == 0)
                return mdissect::mono_method(0);

            const auto name_address = allocate_string(name);
            if (name_address == 0)
                return mdissect::mono_method(0);

            const auto response = rpc_->invoke<uint64_t>(mono_class_get_method_from_name, klass.address, name_address, param_count);

            (void)free(name_address);

            if (response.error != RPC_OK)
                return mdissect::mono_method(0);

            return mdissect::mono_method(response.result);
        }

        uint64_t mono_compile_method(const mdissect::mono_method& method) {
            if (method.address == 0)
                return 0;

            static auto mono_compile_method = get_mono_export_method("mono_compile_method");
            if (mono_compile_method == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>(mono_compile_method, method.address, 0);
            if (response.error != RPC_OK)
                return 0;

            return response.result;
        }

        uint64_t mono_type_get_object(const mdissect::mono_type& type) {
            static const auto mono_type_get_object = get_mono_export_method("mono_type_get_object");
            if (mono_type_get_object == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>(mono_type_get_object, domain_.address, type.address);

            if (response.error != RPC_OK)
                return 0;

            return response.result;
        }

        // UnityEngine.Renderer functions
        void unity_engine_renderer_set_material(const uint64_t renderer, const uint64_t material) {
            static const auto set_material_native_address = mono_compile_method(mono_class_get_method_from_name(unity_engine::renderer::get_mono_klass(), "SetMaterial"));
            if (set_material_native_address == 0)
                return;

            const auto response = rpc_->invoke<uint64_t>(set_material_native_address, renderer, material);
            if (response.error != RPC_OK)
                return;

            // TODO: Maybe assert on failed response
        }

        // UnityEngine.AssetBundle
        unity_engine::asset_bundle unity_engine_asset_bundle_load_from_file(const std::string& path) {
            static const auto load_from_file_native_address = mono_compile_method(mono_class_get_method_from_name(unity_engine::asset_bundle::get_mono_klass(), "LoadFromFile", 1));
            if (load_from_file_native_address == 0)
                return unity_engine::asset_bundle(0);

            const auto path_address = allocate_string(path);
            if (path_address == 0)
                return unity_engine::asset_bundle(0);

            const auto response = rpc_->invoke<uint64_t>(load_from_file_native_address, path_address);

            (void)free(path_address);

            if (response.error != RPC_OK)
                return unity_engine::asset_bundle(0);

            return unity_engine::asset_bundle(response.result);
        }

        template <typename T>
        T unity_engine_asset_bundle_load_asset(const unity_engine::asset_bundle& bundle, const std::string& name) {
            static const auto load_asset_native_address = mono_compile_method(mono_class_get_method_from_name(unity_engine::asset_bundle::get_mono_klass(), "LoadAsset"));
            if (load_asset_native_address == 0)
                return 0;

            // TODO: Should assert for this
            const auto reflection_type = mono_type_get_object(T::get_mono_klass().type());
            if (reflection_type == 0)
                return 0;

            const auto name_address = allocate_string(name);
            if (name_address == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>(load_asset_native_address, bundle.sync_block_address, name_address, reflection_type);

            (void)free(name_address);

            if (response.error != RPC_OK)
                return 0;

            return response.result;

        }

    private:
        [[nodiscard]] uint64_t allocate_string(const std::string& str) const {
            const auto response = rpc_->invoke<uint64_t>((uint64_t) VirtualAlloc, (uint64_t) nullptr, str.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
            if (response.error != RPC_OK)
                return 0;

            memory::write(response.result, str.c_str(), str.size());

            return response.result;
        }

        bool free(const uint64_t address) const {
            const auto response = rpc_->invoke<uint64_t>((uint64_t) VirtualFree, address, 0, MEM_RELEASE);
            if (response.error != RPC_OK)
                return false;

            return response.result;
        }

        uint64_t get_mono_export_method(const std::string& name) {
            static auto mono_dll = get_module_handle("mono-2.0-bdwgc.dll");
            if (mono_dll == 0)
                return 0;

            const auto name_address = allocate_string(name);
            if (name_address == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>((uint64_t) GetProcAddress, mono_dll, name_address);

            (void)free(name_address);

            if (response.error != RPC_OK)
                return 0;

            return response.result;
        }

        uint64_t get_module_handle(const std::string& name) {
            const auto name_address = allocate_string(name);
            if (name_address == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>((uint64_t) GetModuleHandleA, name_address);

            free(name_address);

            if (response.error != RPC_OK)
                return 0;

            return response.result;
        }

        uint64_t get_proc_address(uint64_t mod, const std::string& name) {
            const auto name_address = allocate_string(name);
            if (name_address == 0)
                return 0;

            const auto response = rpc_->invoke<uint64_t>((uint64_t) GetProcAddress, mod, name_address);

            free(name_address);

            if (response.error != RPC_OK)
                return 0;

            return response.result;
        }

        mdissect::mono_domain domain_;
        std::shared_ptr<base_rpc> rpc_;
    };
} // namespace rpc

#endif