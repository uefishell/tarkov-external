#ifndef INPUT_HPP
#define INPUT_HPP

#include <deque>
#include <shared_mutex>

#define INPUT_KEY_FLAG_NONE 0
#define INPUT_KEY_FLAG_LSHIFT 1 << 1
#define INPUT_KEY_FLAG_RSHIFT 1 << 2
#define INPUT_KEY_FLAG_CAPS 1 << 3
#define INPUT_KEY_FLAG_LMENU 1 << 4
#define INPUT_KEY_FLAG_RMENU 1 << 5

#define INPUT_KEY_FLAG_DOWN 1 << 6
#define INPUT_KEY_FLAG_UP 1 << 7

#define INPUT_MOUSE_FLAG_NONE 0
// #define INPUT_MOUSE_FLAG_LBUTTON 1 << 1
// #define INPUT_MOUSE_FLAG_RBUTTON 1 << 2
// #define INPUT_MOUSE_FLAG_XBUTTON1 1 << 3
// #define INPUT_MOUSE_FLAG_XBUTTON2 1 << 4
// #define INPUT_MOUSE_FLAG_MOUSEWHEEL 1 << 5
// #define INPUT_MOUSE_FLAG_MOUSEMOVE 1 << 6

#define INPUT_MOUSE_FLAG_DOWN 1 << 7
#define INPUT_MOUSE_FLAG_UP 1 << 8

namespace input {
    struct key_press {
        uint32_t code;
        uint32_t scan;
        uint32_t flags;
    };

    struct mouse_event {
        uint32_t code;
        uint32_t flags;
        int32_t delta;
        int32_t x, y;
    };

    std::shared_mutex& key_mutex();
    std::shared_mutex& mouse_mutex();

    std::deque<key_press>& key_inputs();
    std::deque<mouse_event>& mouse_inputs();

    void set_lock(bool locked);
    void set_active(bool active);

    void enable(bool keyboard, bool mouse);
    void disable();
} // namespace input

#endif //INPUT_INPUT_HPP
