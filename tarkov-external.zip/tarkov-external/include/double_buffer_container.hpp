#ifndef DOUBLE_BUFFER_CONTAINER_HPP
#define DOUBLE_BUFFER_CONTAINER_HPP

#include <atomic>
#include <memory>
#include <shared_mutex>

template <typename T>
class double_buffer_container {
public:
    double_buffer_container() {
        active = std::make_shared<T>();
        working = std::make_shared<T>();
    }

    void swap() {
        std::unique_lock lock_guard(mutex);
        std::swap(active, working);
    }

    void clear() {
        std::unique_lock lock_guard(mutex);
        active->clear();
        working->clear();
    }

    std::shared_mutex mutex {};
    std::shared_ptr<T> active;
    std::shared_ptr<T> working;
};

#endif
