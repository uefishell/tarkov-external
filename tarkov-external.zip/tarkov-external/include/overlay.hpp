#ifndef OVERLAY_HPP
#define OVERLAY_HPP

#include <string>

namespace overlay {
    inline size_t frame_time = 0;

    extern uint32_t width;
    extern uint32_t height;

    void enable(const std::string& target);
} // namespace overlay

#endif