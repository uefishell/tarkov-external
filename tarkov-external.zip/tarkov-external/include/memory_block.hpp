#ifndef _MEMORY_MEMORY_BLOCK_HPP_
#define _MEMORY_MEMORY_BLOCK_HPP_

#include "memory.hpp"

#define SYNC_FIELD(T, NAME, OFFSET)                                                                           \
    __forceinline element<T, true> NAME() const {                                                             \
        static_assert(this->klass_size() > OFFSET, "OFFSET IS GREATER THAN BUFFER!");                         \
        return element<T, true>(*((T*) &this->memory_block_data[OFFSET]), this->sync_block_address + OFFSET); \
    }

#define FIELD(T, NAME, OFFSET)                                                        \
    __forceinline T& NAME() const {                                                   \
        static_assert(this->klass_size() > OFFSET, "OFFSET IS GREATER THAN BUFFER!"); \
        return *((T*) &this->memory_block_data[OFFSET]);                              \
    }

template <size_t N>
struct memory_block {
    uint8_t memory_block_data[N];

    [[nodiscard]] inline uint8_t& operator[](size_t index) {
        return this->memory_block_data[index];
    }

    [[nodiscard]] static inline constexpr size_t klass_size() {
        return N;
    }
};

template <size_t N>
struct sync_block : public memory_block<N> {
    sync_block() = default;

    explicit sync_block(uint64_t address) : sync_block_address(address) {
        if (address != 0)
            (void) this->read();
    }

    bool read() {
        return memory::read(this->sync_block_address, this->memory_block_data, N);
    }

    bool write() {
        return memory::write(sync_block_address, this->memory_block_data, N);
    }

    operator bool() const {
        return sync_block_address != 0;
    }

    operator uint64_t() const {
        return sync_block_address;
    }

    uint64_t sync_block_address = 0;
};

template <typename T, bool SYNC = false>
struct element {
    T& value;
    uint64_t address;

    element(T& value, uint64_t address) : value(value), address(address) {}

    element& operator=(const element& other) {
        if constexpr (SYNC) {
            memory::write<T>(address, other.value);
        }

        *this = other;
        return *this;
    }

    element& operator=(const T& other) {
        if constexpr (SYNC) {
            memory::write<T>(address, other);
        }

        this->value = other;
        return *this;
    }

    const element& operator=(const T& other) const {
        if constexpr (SYNC) {
            memory::write<T>(address, other);
        }

        this->value = other;
        return *this;
    }
};

#endif