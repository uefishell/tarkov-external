#ifndef LOCALIZATION_HELPER_HPP
#define LOCALIZATION_HELPER_HPP

#include "sdk.hpp"

#include <string>
#include <unordered_map>

namespace localization_helper {
    bool find_localized(const std::wstring& id, const std::wstring& locale, std::wstring& localizedValue);
    std::wstring find_localized(const std::wstring& id, const std::wstring& locale);
    std::wstring localized(const std::wstring& id);
    std::wstring localized(std::wstring id, const std::wstring& prefix);
    std::wstring localized_area_name(eft::e_area_type type);
    std::wstring localized_name(const std::wstring& itemTemplateId);
    std::wstring localized_short_name(const std::wstring& itemTemplateId);
} // namespace localization_helper

#endif