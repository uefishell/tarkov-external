#ifndef HTTP_TRANSPORT_HPP
#define HTTP_TRANSPORT_HPP

#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <string>
#include <zlib.h>

// https://tulach.cc/reversing-eft-s-player-profile-api/
namespace http_transport {
    mdissect::mono_class get_http_transport_class() {
        static mdissect::mono_class http_transport_class;
        if (http_transport_class.address != 0)
            return http_transport_class;

        const auto assembly = mdissect::get_assembly_image("Assembly-CSharp");
        if (assembly.address == 0)
            return {};

        for (const auto& type: assembly.types()) {
            if (type.address == 0)
                continue;

            for (const auto& method: type.methods()) {
                if (method.address == 0)
                    continue;

                if (method.name() == "add_OnErrorHandledWithResult") {
                    http_transport_class = type;
                    return http_transport_class;
                }
            }
        }
    }

    // private static readonly byte[] byte_0 = Encoding.UTF8.GetBytes("Qo*np7*yPHqWX8ZB3ZO@m1k4");
    uint32_t find_key_static_field_offset(mdissect::mono_class http_transport_class) {
        static bool found = false;
        static uint32_t key_offset = 0;

        if (found)
            return key_offset;

        for (const auto& field: http_transport_class.fields()) {
            const auto type = field.type();

            // TODO: Generic type check and then we need to see if it's a dotnet::array<byte>
            // byte_class = mono_base + 0x1804A21B0;
        }

        return 0;
    }

    std::vector<uint8_t> decrypt_bytes(const std::vector<uint8_t>& cipher_text, const std::vector<uint8_t>& key, const std::vector<uint8_t>& iv) {
        std::vector<uint8_t> decrypted_text(cipher_text.size());
    }

    std::vector<uint8_t> process_data(const std::vector<uint8_t>& key, std::vector<uint8_t>& iv, const std::vector<uint8_t>& data) {
        const auto actual_data_length = data.size() - iv.size();
        std::vector<uint8_t> actual_data(actual_data_length);

        std::copy(data.begin() + iv.size(), data.end(), actual_data.begin());
        std::copy(data.begin(), data.begin() + iv.size(), iv.begin());
    }

    uint64_t static_field_data;

    std::vector<uint8_t> get_key() {
        dotnet::array<uint8_t> array(memory::read<uint64_t>(static_field_data + 0x0));
        return array.data;
    }

    // private static readonly ObjectPool<byte[]> objectPool_0;
    // TODO: Array probably won't work for object pool I legit just can't test rn because the game is down
    std::vector<uint8_t> get_iv() {
        dotnet::array<uint8_t> array(memory::read<uint64_t>(static_field_data + 0x8));
        return array.data;
    }

    void query_other_player_profile(const std::wstring& account_id) {
        if (static_field_data == 0) {
            const auto http_transport_class = get_http_transport_class();
            if (http_transport_class.address == 0)
                return;

            static_field_data = get_static_field_data(http_transport_class);
        }

        const auto key = get_key();
        const auto iv = get_iv();

        // Should we just use CryptoPP?
    }
} // namespace http_transport

#endif