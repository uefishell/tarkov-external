#ifndef GAME_HPP
#define GAME_HPP

#include "config.hpp"
#include "globals.hpp"
#include "localization_helper.hpp"
#include "market.hpp"
#include "rpc/mono_rpc.hpp"

#include <typeinfo>

// Quest names https://www.unknowncheats.me/forum/3334574-post5822.html
namespace game {
    bool initialize();

    extern uint64_t _mono_runtime;

    inline std::unordered_map<uint64_t, uint64_t> singleton_statics;

    // TODO: Queue searching for singleton instances that were not found to be delayed since searching for them when not found is expensive
    template <typename T>
    T get_singleton_instance() {
        const auto target = T::get_mono_klass().type_token();

        // Find the singleton instance in singleton_classes
        const auto cached_static_field_data = singleton_statics.find(target);
        if (cached_static_field_data != singleton_statics.end()) {
            return T(memory::read<uint64_t>(cached_static_field_data->second));
        }

        for (int32_t i = 0; i < HASH_TABLE_SIZE; i++) {
            auto image_set = mdissect::get_image_set_cache_entry(i);
            if (image_set.address == 0)
                continue;

            const auto hash_table = image_set.hash_table();
            if (hash_table == 0)
                continue;

            const auto table = memory::read<uint64_t>(hash_table);
            if (table == 0)
                continue;

            const auto table_entries = memory::read<uint64_t>(table + 0x8);
            if (table_entries == 0)
                continue;

            const auto table_size = memory::read<int32_t>(table);

            for (size_t j = 0; j < table_size; j++) {
                auto generic_class = memory::read<uint64_t>(table_entries + j * 0x10);
                if (generic_class == 0)
                    continue;

                const auto klass = mdissect::mono_class(memory::read<uint64_t>(generic_class + 0x20));
                if (klass.address == 0)
                    continue;

                // TODO: Would be a good idea to check if the classes are initalized right?
                //if (memory::read<uint8_t>(klass.address + 0x20) & 1 != 1 ||                 // inited
                //    (memory::read<uint32_t>(klass.address + 0x28) & 0x800000) != 0 ||       // exception_type !!+ EXCEPTION_NONE
                //    (memory::read<uint32_t>(klass.address + 0x28) & 0x70000) != 0x30000 )   // class_kind !+ CLASS_GINST
                //    continue;

                if (klass.name_space().contains("Comfort.Common") && klass.name().contains("Singleton")) {
                    generic_class = memory::read<uint64_t>(klass.address + 0xF0);
                    if (generic_class == 0)
                        continue;

                    const auto generic_class_context = memory::read<uint64_t>(generic_class + 0x8);
                    if (generic_class_context == 0)
                        continue;

                    const auto argument_class_type = memory::read<uint64_t>(generic_class_context + 0x8);
                    if (argument_class_type == 0)
                        continue;

                    const auto argument_class = mdissect::mono_class(memory::read<uint64_t>(argument_class_type));
                    if (argument_class.address == 0)
                        continue;

                    if (argument_class.type_token() == target) {
                        DPRINTF("[+] found comfort::common::singleton_1<{}> [{}] at {}\n", typeid(T).name(), target, (void*)argument_class.address);
                        const auto static_field_data = mdissect::get_static_field_data(klass);
                        singleton_statics[target] = static_field_data;
                        return T(memory::read<uint64_t>(static_field_data));
                    }
                }
            }
        }

        return {};
    }

    void very_fast_update();
    void fast_update();
    void slow_update();
    void very_slow_update();

    void update_camera_data();

    bool world_to_screen(glm::vec3 world, glm::vec2& screen);

    uint64_t get_object_transform(uint64_t address);
    glm::vec3 get_transform_position(uint64_t transform);

    struct list_element {
        uint64_t prev;
        uint64_t next;
    };

    struct game_object_manager : sync_block<0x30> {
        game_object_manager() = default;
        explicit game_object_manager(uint64_t address) : sync_block(address) {}

        // List<ListNode<GameObject>>
        SYNC_FIELD(list_element, tagged_nodes, 0x0);
        SYNC_FIELD(list_element, main_camera_tagged_nodes, 0x10);
        SYNC_FIELD(list_element, active_nodes, 0x20);

        uint64_t find_object_from_list(list_element list, std::wstring object_name);
    };

    game_object_manager get_game_object_manager();

    float fov_to_pixel_distance(float fov_in);

    // External function calling
    // https://github.com/mono/mono/blob/9bb01f57a126dab35f070ce238457931e9814c33/mono/metadata/object.c#L3056
    // Can do a hook that hooks some mono thing (like runtime invoke) that will be in the game thread
    // https://github.com/migueldeicaza/mono-wasm-mono/blob/8eb6ac3a88b9e6ca5127dce5a3d3c075bf1586a4/mono/metadata/object-internals.h#L631
    // Hook any of these
    /*struct stub_data_t {
        uint64_t fn;
        uint64_t rcx;
        uint64_t rdx;
        uint64_t r8;
        uint64_t r9;
        uint64_t result;
        uint64_t orig_fn;
    };

    void call_stub(...) {
        stub_data_t* data = (stub_data_t*)0xFEEDB00BC0DEBABE;

        using fn_t = uint64_t(*)( uint64_t, uint64_t, uint64_t, uint64_t );
        data->result = ((fn_t)data->fn)( rcx, rdx, r8, r9 );
        return (void(*)(...))(orig_fn)(...);
    }*/

    // uint64_t test = 0xDEADBEEF;

    renderer::color_rgba get_rarity_color(int32_t rarity);

    std::wstring format_price(int64_t price);

    bool is_rarity_good(int32_t rarity);
    bool is_quest_item(const std::wstring& id);
    int32_t get_item_rarity(const std::wstring& name, const std::wstring& id, int32_t price, market::item_types type, bool map_quest_item);
    void format_market_item(const std::wstring& id, std::wstring& label, int32_t& rarity, int32_t& price, bool full_name = false);

    /*void format_ammo_item(eft::inventory_logic::item* item, std::wstring& label) {
        static const std::wstring caliber {L"Caliber"};
        std::wstring caliber_name;
        int32_t ammo_count = 0;
        if (item->is_type_of(eft::inventory_logic::ammo::get_ammo_type())) {
            const auto ammo_temp = reinterpret_cast<eft::inventory_logic::ammo_template*>(item->template_());
            caliber_name = ammo_temp->caliber()->to_wstring();
        } else if (item->is_type_of(eft::inventory_logic::ammo_box::get_ammo_box_type())) {
            const auto ammo_box = reinterpret_cast<eft::inventory_logic::ammo_box*>(item);
            const auto ss = ammo_box->cartridges();
            if (ss == nullptr)
                return;

            const auto ammo_list = ss->items();
            if (ammo_list == nullptr)
                return;

            eft::inventory_logic::item* ammo_item = nullptr;

            for (auto* item: *ammo_list) {
                if (item == nullptr)
                    continue;

                ammo_item = item;
                break;
            }

            if (ammo_item == nullptr)
                return;

            const auto ammo_temp = reinterpret_cast<eft::inventory_logic::ammo_template*>(ammo_item->template_());
            caliber_name = ammo_temp->caliber()->to_wstring();
            ammo_count = ss->get_count_prop();
        }
        if (caliber_name.empty())
            return;

        const auto pos = caliber_name.find(caliber);
        if (pos != std::string::npos)
            caliber_name.erase(pos, caliber.length());

        label.insert(0, caliber_name + L' ');
        if (ammo_count > 0)
            label.append(std::format(L" {}x", ammo_count));
    }*/

    void sort_items_by_price(std::vector<game::container_item>& items);

    // TODO: Move elsewhere
    constexpr std::array<const wchar_t*, 15> slot_names {
        L"FirstPrimaryWeapon",
        L"SecondPrimaryWeapon",
        L"Holster",
        L"Scabbard",
        L"Backpack",
        L"SecuredContainer",
        L"TacticalVest",
        L"ArmorVest",
        L"Pockets",
        L"Eyewear",
        L"FaceCover",
        L"Headwear",
        L"Earpiece",
        L"Dogtag",
        L"ArmBand"};

    void add_item_to_container(std::vector<game::container_item>& container, const eft::inventory_logic::item& item);
    void add_grids_to_container(std::vector<game::container_item>& container, uint64_t grids_address, bool player_grids = false, std::wstring_view parent_slot_id = {});
    void add_slots_to_container(std::vector<game::container_item>& container, uint64_t slots_address, bool player_slots = false);
} // namespace game

#endif