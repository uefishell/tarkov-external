#pragma once

bool ImGui_ImplWin32_WndProcHandler_Hook(void* hwnd);