#ifndef CUSTOM_PLAYER_HPP
#define CUSTOM_PLAYER_HPP

namespace sdk {
    class cached_main_player {
    private:
        eft::player player_;
        //eft::animations::proce
    };

    class cached_player {
    private:
        // All of these fields should be stored as shared pointers probably, so if it's not in use it won't take up the size of its data block

        // Player cached information
        struct player_data {
            eft::player player_;
            eft::profile player_profile_;
            eft::profile_info player_profile_info_;
            eft::movement_context player_movement_context_;
            eft::health_system::health_controller<uint64_t> player_health_controller_;
            eft::profile_settings player_profile_settings_;
        };

        std::shared_ptr<player_data> player_;

        // Observed
        struct observed_data {
            eft::next_observed_player::observed_player_view observed_;
            eft::next_observed_player::observed_player_controller observed_player_controller_;
            eft::next_observed_player::health_controller observed_player_health_controller_;
            eft::next_observed_player::movement_controller observed_player_movement_controller_;
            eft::next_observed_player::state_context observed_player_state_context_;
        };

        std::shared_ptr<observed_data> observed_;

        // Shared
        std::wstring group_id_;
        std::wstring team_id_;
        eft::ai_data ai_data_;
        std::wstring profile_id_;
        std::wstring account_id_;
        eft::player_bones player_bones_;
        eft::player_body player_body_;
        diz::skinning::skeleton player_body_skeletal_root_joint_;
        dotnet::collections::generic::list_1<uint64_t> player_body_transforms_;

        std::unordered_map<bone_id, unity_engine::transform_internal> internal_transforms_;

        std::wstring name_;

        // Extra
        float health_;

    public:
        std::unordered_map<bone_id, glm::vec3> bones_;
        bool oof_;

    public:
        cached_player(uint64_t address);

        // Update data that changes frequently such as positions and rotations
        void partial_update();

        int32_t id();
        eft::e_player_side side();
        std::wstring group_id();
        std::wstring team_id();
        glm::vec3 look_direction();
        glm::vec3 position();
        eft::bifacial_transform transform();
        eft::bifacial_transform weapon_root();
        unity_engine::game_object hands_item_object();
        //health_system::health_controller health_controller();
        eft::profile profile();
        eft::ai_data ai_data();
        //player_loyalty_data loyalty();
        bool is_ai();
        //sdk::dictionary<e_body_part,enemy_part> main_parts();
        std::wstring profile_id();
        std::wstring account_id();
        eft::player_bones player_bones();
        bool is_your_player();
        eft::player_body player_body();
        //icharacter_controller character_controller();
        //uint8_t channel_index();
        //bool is_in_buffer_zone();
        //bool state_is_suitable_for_hand_input();
        glm::vec2 rotation();
        glm::vec3 velocity();

        [[nodiscard]] bool destroyed();
        [[nodiscard]] bool is_dead_already();
        [[nodiscard]] float health();
        [[nodiscard]] bool is_savage();
        [[nodiscard]] std::wstring name();
    };
} // namespace sdk

#endif