#ifndef OFFSETS_HPP
#define OFFSETS_HPP

#include <cstdint>

namespace offsets {
    constexpr int32_t mono_root_domain = 0x499C78;               // mono_root_domain
    constexpr int32_t disable_discord_present_counter = 0xE9148; // "8B 05 ?? ?? ?? ?? 65 48 8B 0C 25 58 00 00 00 48 8B 04 C1 48 83 B8 08" // 0x1911E
    constexpr int32_t discord_present_count = 0xF1190;
    constexpr int32_t swap_chain_present_conditional = 0x17877; // "56 57 53 48 83 EC 30 44" + 0x2D
    constexpr int32_t all_cameras = 0x179F500;                  // UnityPlayer.dll!s_AllCamera
    constexpr int32_t manager_context = 0x17FFAE0;
    constexpr int32_t terrain_manager = 0x18401D8;              //GetITerrainManager()
    constexpr int32_t game_object_manager = 0x17FFD28;          // UnityPlayer.dll!GameObjectManager::s_Instance;
    constexpr int32_t eft_screen_controller_token = 0x020022BB; //<>.CloseAllScreensForced();
} // namespace offsets

#endif