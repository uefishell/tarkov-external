#ifndef CUSTOM_STRUCTS_HPP
#define CUSTOM_STRUCTS_HPP

#include "sdk.hpp"

#include <array>
#include <cstdint>

enum aimbot_target_selection_type : int32_t {
    target_selection_fov,
    target_selection_distance,
    target_selection_health
};

enum aimbot_target_bone : int32_t {
    target_head,
    target_thorax,
    target_arms,
    target_legs
};

enum box_type : int32_t {
    box_none,
    box_2d,
    box_2d_corner,
    box_3d,
    box_3d_corner
};

enum cham_material_type : int32_t {
    material_flat,
    material_force_field,
    material_wireframe
};

enum tracer_render_type : int32_t {
    tracers_render_line,
    tracers_render_trail // Use UnityEngine.TrailRenderer
};

enum trail_tracer_texture_type : int32_t {
    trail_texture_beam,
    trail_texture_laser,
    trail_texture_lightning
};

enum hit_indicator : int32_t {
    hit_indicator_none,
    hit_indicator_2d, // 2d centered hitmarker
    hit_indicator_3d, // 2d hitmarker positioned in 3d space
    hit_indicator_3d_normal // 2d hitmarker aligned on the hit_normal
};

enum hit_marker_sound : int32_t {
    hit_marker_boom,
    hit_marker_cod,
    hit_marker_hitsound,
    hit_marker_metal,
    hit_marker_punch,
    hit_marker_qbeep,
    hit_marker_roblox,
    hit_marker_skeet
};

enum speed_hack_mode : int32_t {
    speed_hack_timescale,
    speed_hack_flash,
    speed_hack_transform,
    speed_hack_direct
};

enum player_stance : int32_t {
    standing,
    prone,
    transit2prone
};

enum visibility : int32_t {
    hidden,
    can_penetrate,
    visible
};

// https://db.sp-tarkov.com/search/55d7217a4bdc2d86028b456d
constexpr std::array<const wchar_t*, 15> slot_names {
    L"FirstPrimaryWeapon",
    L"SecondPrimaryWeapon",
    L"Holster",
    L"Scabbard",
    L"Backpack",
    L"SecuredContainer",
    L"TacticalVest",
    L"ArmorVest",
    L"Pockets",
    L"Eyewear",
    L"FaceCover",
    L"Headwear",
    L"Earpiece",
    L"Dogtag",
    L"ArmBand"
};

constexpr std::array<std::pair<const char*, bone_id>, 4> target_bones {
    std::pair<const char*, bone_id>{"Head", human_head},
    std::pair<const char*, bone_id>{"Thorax", human_spine3},
    std::pair<const char*, bone_id>{"Legs", human_left_thigh2},
    std::pair<const char*, bone_id>{"Arms", human_left_upperarm}
};

constexpr std::array<std::pair<const char*, eft::e_player_state>, 3> resolver_state {
    std::pair<const char*, eft::e_player_state>{"Standing", eft::e_player_state::idle},
    std::pair<const char*, eft::e_player_state>{"Prone", eft::e_player_state::prone_idle},
    std::pair<const char*, eft::e_player_state>{"Transit to prone", eft::e_player_state::transit2prone}
};

constexpr std::array<std::pair<const char*, int32_t>, 2> tracer_render_types {
    std::pair<const char*, int32_t>{"Line", tracers_render_line},
    std::pair<const char*, int32_t>{"Trail", tracers_render_trail}
};

constexpr std::array<std::pair<const char*, int32_t>, 2> trail_tracer_texture_types {
    std::pair<const char*, int32_t>{"Beam", trail_texture_beam},
    std::pair<const char*, int32_t>{"Laser", trail_texture_laser}
};

constexpr std::array<std::pair<const char*, int32_t>, 4> hit_marker_types {
    std::pair<const char*, int32_t>{"None", hit_indicator_none},
    std::pair<const char*, int32_t>{"2D", hit_indicator_2d},
    std::pair<const char*, int32_t>{"3D", hit_indicator_3d},
    std::pair<const char*, int32_t>{"3D normal", hit_indicator_3d_normal}
};

constexpr std::array<std::pair<const char*, int32_t>, 4> speed_hack_types {
    std::pair<const char*, int32_t>{"Timescale", speed_hack_timescale},
    std::pair<const char*, int32_t>{"Flash", speed_hack_flash},
    std::pair<const char*, int32_t>{"Transform", speed_hack_transform},
    std::pair<const char*, int32_t>{"Direct", speed_hack_direct}
};

constexpr std::array<std::pair<const char*, const wchar_t*>, 3> chams_types {
    std::pair<const char*, const wchar_t*>{"Flat", L"assets/kiwicheats/shaders/flat.shader"},
    std::pair<const char*, const wchar_t*>{"Force field", L"assets/kiwicheats/shaders/force_field.shader"},
    std::pair<const char*, const wchar_t*>{"Wireframe", L"assets/kiwicheats/shaders/wireframe.shader"}
};

constexpr std::array<std::pair<const char*, const wchar_t*>, 8> hit_marker_sounds {
    std::pair<const char*, const wchar_t*>{"Boom", L"assets/kiwicheats/sounds/boom.wav"},
    std::pair<const char*, const wchar_t*>{"COD", L"assets/kiwicheats/sounds/cod.wav"},
    std::pair<const char*, const wchar_t*>{"Hitsound", L"assets/kiwicheats/sounds/hitsound.wav"},
    std::pair<const char*, const wchar_t*>{"Metal", L"assets/kiwicheats/sounds/metal.wav"},
    std::pair<const char*, const wchar_t*>{"Punch", L"assets/kiwicheats/sounds/punch.wav"},
    std::pair<const char*, const wchar_t*>{"QBeep", L"assets/kiwicheats/sounds/qbeep.wav"},
    std::pair<const char*, const wchar_t*>{"Roblox", L"assets/kiwicheats/sounds/roblox.wav"},
    std::pair<const char*, const wchar_t*>{"Skeet", L"assets/kiwicheats/sounds/skeet.wav"}
};

constexpr std::array<const char*, 5> player_box_types = {"None", "2D", "2D corner", "3D", "3D corner"};
constexpr std::array<const char*, 3> aimbot_target_types = {"Field of view", "Distance", "Health"};
constexpr std::array<const char*, 4> aimbot_bone_types = {"Head", "Thorax", "Arms", "Legs"};

#endif