#ifndef MARKET_HPP
#define MARKET_HPP

namespace dotnet {
    class string;
}

#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

constexpr std::string_view MARKET_DATA_JSON = "market_data.exjson";

namespace market {
    enum item_types : uint32_t {
        gun = (1 << 0),
        wearable = (1 << 1),
        ammo_box = (1 << 2),
        keys = (1 << 3),
        ammo = (1 << 4),
        grenade = (1 << 5),
        mods = (1 << 6),
        provisions = (1 << 7),
        no_flea = (1 << 8),
        disabled = (1 << 9),
        armor = (1 << 10),
        rig = (1 << 11),
        backpack = (1 << 12),
        meds = (1 << 13),
        injectors = (1 << 14),
        barter = (1 << 15),
        glasses = (1 << 16),
        pistol_grip = (1 << 17),
        suppressor = (1 << 18),
        helmet = (1 << 19),
        headphones = (1 << 20),
        container = (1 << 21),
        marked_only = (1 << 22),
        price = (1 << 23),
        money = (1 << 24),
    };

    enum class item_type_idx : uint32_t {
        gun,
        wearable,
        ammo_box,
        keys,
        ammo,
        grenade,
        mods,
        provisions,
        no_flea,
        disabled,
        armor,
        rig,
        backpack,
        meds,
        injectors,
        barter,
        glasses,
        pistol_grip,
        suppressor,
        helmet,
        headphones,
        container,
        marked_only,
        price,
        money,
    };

    const inline std::unordered_map<std::string, item_types> type_map = {
        {"gun", gun},
        {"wearable", wearable},
        {"ammoBox", ammo_box},
        {"keys", keys},
        {"ammo", ammo},
        {"grenade", grenade},
        {"mods", mods},
        {"provisions", provisions},
        {"noFlea", no_flea},
        {"disabled", disabled},
        {"armor", armor},
        {"rig", rig},
        {"backpack", backpack},
        {"meds", meds},
        {"injectors", injectors},
        {"barter", barter},
        {"glasses", glasses},
        {"pistolGrip", pistol_grip},
        {"suppressor", suppressor},
        {"helmet", helmet},
        {"headphones", headphones},
        {"container", container},
        {"markedOnly", marked_only}};

    struct market_item {
        std::wstring name;
        std::wstring short_name;
        int32_t flea_price;
        int32_t trader_price;
        item_types type;
        bool quest_item;

        // Deprecated I don't know why we did this when we can just check if the type & money
        //bool money;
    };

    struct api_objective {
        std::wstring id;
        std::vector<std::wstring> maps;
    };

    struct api_quest {
        std::vector<api_objective> objectives;
    };

    extern bool market_api_curl_success;
    extern std::shared_mutex market_mutex;
    extern std::shared_mutex user_filter_mutex;
    bool update();

    bool get_item(const std::wstring& template_item_id, market_item& item);
    bool get_quest(const std::wstring& template_quest_id, api_quest& quest);
    bool in_user_filter(const std::wstring& id);
    std::list<std::pair<std::wstring, std::string>>& get_item_user_filter();
    std::unordered_map<std::wstring, market_item>& get_item_information();
} // namespace market

#endif