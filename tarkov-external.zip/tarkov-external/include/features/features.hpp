#ifndef FEATURES_FEATURES_HPP
#define FEATURES_FEATURES_HPP

#include "game.hpp"

namespace features {
    void aimbot();
    void misc();
    void test();
    void visuals();
} // namespace features

namespace visuals {
    void loot();
}

#endif