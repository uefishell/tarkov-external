#ifndef MRTTI_HPP
#define MRTTI_HPP

#include <mdissect/mdissect.hpp>

// TODO: Maybe unused delete this if so it's 5am rn
namespace mrtti {
    struct type_id {
        type_id() = default;
        explicit type_id(uint64_t id) : id(id) {}

        uint64_t id;

        bool __forceinline operator==(const type_id other) const {
            return id == other.id;
        }

        bool __forceinline operator!=(const type_id other) const {
            return !(*this == other);
        }

        [[nodiscard]] __forceinline mdissect::mono_class mono_class() const {
            return mdissect::mono_class(id);
        }
    };

    __forceinline static type_id get_id(mdissect::mono_class mono_class) {
        return type_id(mono_class.address);
    }

    __forceinline static type_id get_id(mdissect::mono_object mono_object) {
        return get_id(mono_object.vtable().mono_class());
    }
} // namespace mrtti

#endif